#include<stdio.h>
int main()
{
     int i,n;
     
     printf("enter the size of array :");
     
     scanf("%d",&n);
     
     int x[n];
     
     for(i=0;i<n;i++)
     {
          
          scanf("%d",&x[i]);
          
     }
     
     printf("\nthis is all even  numbers present in array :");
     for(i=0;i<n;i++)
     {
          if(x[i]%2==0)
          printf("\n%d\t",x[i]);
     }
     printf("\n------------------------------------------------");
     printf("\nthis is all odd numbers present in your array:");
     for(i=0;i<n;i++)
     {
          if(x[i]%2!=0)
          printf("\n%d\t",x[i]);
     }
     return 0;
}

