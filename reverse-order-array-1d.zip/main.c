#include<stdio.h>
int main()
{
   int i,n,sum=0,avrg=0;
   
   printf("Enter the size of array :");
   
   scanf("%d",&n);
   
   int x[n];
   
   for(i=0;i<n;i++)
{
        scanf("%d",&x[i]);
        sum+=x[i];
   }
   
   for(i=0;i<n;i++)
   {
        avrg=sum/n;
   }
   
   printf("\nthis is sum of array : %d\n",sum);
   
   printf("\nthis is average value of the array : %d",avrg);
   
   return 0;
}