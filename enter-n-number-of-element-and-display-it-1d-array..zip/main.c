#include<stdio.h>
int main()
{
	int i,n;
	
	printf("enter the size of array :");
	
	scanf("%d",&n);
	
	int x[n];
	
	for(i=0;i<n;i++)
	{
		
		scanf("%d",&x[i]);
		
	}
	
	printf("this is your array :");
	
	for(i=0;i<n;i++)
	{
		
		printf("%d\t",x[i]);
	
	}
	
	printf("\n");
	
	return 0;
}