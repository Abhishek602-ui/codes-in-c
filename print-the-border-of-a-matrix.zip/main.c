#include<stdio.h>
int main()
{
     int x[3][3],i,j;
     
     for(i=0;i<3;i++)
     {
          
          for(j=0;j<3;j++)
          {
               
               scanf("%d",&x[i][j]);
               
          }
          
     }
     
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               if(i==0 || j==0 || i==2 || j==2)
               {
                    printf("%d\t",x[i][j]);
               }
               else 
               printf(" \t");
          }
          printf("\n");
     }
     return 0;
}