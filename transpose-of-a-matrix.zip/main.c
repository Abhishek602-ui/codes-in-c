#include<stdio.h>
int main()
{
     int a,b,i,j;
     
     printf("enter the size of 2d array row and column :");
     
     scanf("%d%d",&a,&b);
     
     int x[a][b];
     
     for(i=0;i<a;i++)
     {
          
          for(j=0;j<b;j++)
          {
               
               scanf("%d",&x[i][j]);
               
          }
          
     }
     
     for(i=0;i<a;i++)
     {
          
          for(j=0;j<b;j++)
          {
               
               printf("%d\t",x[j][i]);
               
          }
     }
     
     return 0;
}