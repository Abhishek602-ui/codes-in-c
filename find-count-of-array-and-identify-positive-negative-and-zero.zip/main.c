#include<stdio.h>
int main()
{
     int i,n,pos=0,neg=0,zero=0,count=0;
     
     printf("Enter the size of array :");
     
     scanf("%d",&n);
     
     int x[n];
        
     for(i=0;i<n;i++)
     {
          
          scanf("%d",&x[i]);
          count++;
     }
     
     for(i=0;i<n;i++)
     {
          
          if(x[i]>0)
          {
               pos++;
          }
          else if(x[i]<0)
          {
               neg++;
          }
          
          else  
          {
               zero++;
          }
          
     }
     
     
          printf("\n counts : %d\n",count);
          printf("\n positive : %d\n",pos);
          printf("\n negative : %d\n",neg);
          printf("\n zero : %d",zero);
    
     
     return 0;
}