#include<stdio.h>
int main()
{
     int x[3][3],i,j,k=0;
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               scanf("%d",&x[i][j]);
          }
     }
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               if(x[i][j]==1)
               {
                    k++;
               }
          }
     }
     if(k==9)
     {
          printf("This is identity matrix ");
     }
     else 
     {
          printf("This is not identity matrix ");
     }
     
     return 0;
}