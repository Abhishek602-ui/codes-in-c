#include<stdio.h>
int main()
{
     int x[3][3],y[3][3],z[3][3],i,j,k,sum;
     
     printf("Enter the 1st matrix :\n");
     
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               scanf("%d",&x[i][j]);
          }
     }
     printf("This is your first matrix :\n");
     
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               printf("%d\t",x[i][j]);
          }
          printf("\n");
     }
     printf("\nEnter the 2nd matrix :");
     
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               scanf("%d",&y[i][j]);
               
          }
     }
     printf("\nThis is your 2nd matrix:\n");
     
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               printf("%d\t",y[i][j]);
          }
          printf("\n");
     }
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               z[i][j]=0;
               for(k=0;k<3;k++)
               {
                    z[i][j]+=x[i][k]*y[k][j];
               }
     
               
          }
     }
     printf("\n This is your product 1st and 2nd matrix :\n");
     for(i=0;i<3;i++)
     {
          for(j=0;j<3;j++)
          {
               printf("%d\t",z[i][j]);
          }
          printf("\n");
     }
     return 0;
}